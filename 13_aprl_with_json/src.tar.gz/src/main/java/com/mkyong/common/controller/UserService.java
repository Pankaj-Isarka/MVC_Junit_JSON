package com.mkyong.common.controller;

import java.util.List;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

	@Autowired
	private EntityManagerFactory entityManagerFactory;

	public User addUser(User user) {

		
		if(Pattern.matches("[a-zA-Z]+", user.getName())) 
		{
			// Get EntityManger from factory.
			EntityManager entityManager = entityManagerFactory
					.createEntityManager();

			// Being Transaction
			entityManager.getTransaction().begin();
			entityManager.persist(user);

			entityManager.flush();
			entityManager.getTransaction().commit();
			// End and flush transaction to database.

			return user;
		}
		else{
		return null;
/*		// Get EntityManger from factory.
		EntityManager entityManager = entityManagerFactory
				.createEntityManager();

		// Being Transaction
		entityManager.getTransaction().begin();
		entityManager.persist(user);

		entityManager.flush();
		entityManager.getTransaction().commit();
		// End and flush transaction to database.

		return user;*/
	}
	}
	public User UpdateUser(User user) {

		// Get EntityManger from factory.
		EntityManager entityManager = entityManagerFactory
				.createEntityManager();
		System.out.println("in User service update");
		// Being Transaction
		entityManager.getTransaction().begin();
		User user1 = entityManager.find(User.class, user.getId());// find id to
																	// be
																	// updated
		if (user1 == null) {
			return null;
		} else {
			user1.setName(user.getName());// updating name
			user1.setUsername(user.getUsername());// updating username
			entityManager.persist(user1);

			entityManager.flush();
			entityManager.getTransaction().commit();
			// End and flush transaction to database.
			return user;
		}
	}

	public User FindUser(User user) {

		// Get EntityManger from factory.
		EntityManager entityManager = entityManagerFactory
				.createEntityManager();
		System.out.println("just for testing update call");
		// Being Transaction
		entityManager.getTransaction().begin();

		User findUser = entityManager.find(User.class, user.getId());// find id																	 
		//System.out.println("User id " + user.getId());
		entityManager.getTransaction().commit();
		// End and flush transaction to database.
		return findUser;
	}

	public User DeleteUser(User user) {

		// Get EntityManger from factory.
		EntityManager entityManager = entityManagerFactory
				.createEntityManager();

		// Being Transaction
		entityManager.getTransaction().begin();

		User delUser = entityManager.find(User.class, user.getId());// find id
																	// to be
																	// deleted
		// System.out.println("User id "+user.getId());
		if (delUser == null) {
			return null;
		} else {
			entityManager.remove(delUser);// deleting data from database

			entityManager.getTransaction().commit();
			// End and flush transaction to database.
			return user;
		}
	}

	public User SelectUser(User user) {

		// Get EntityManger from factory.
		EntityManager entityManager = entityManagerFactory
				.createEntityManager();

		// Being Transaction
		entityManager.getTransaction().begin();

		User selectUser = entityManager.find(User.class, user.getId());// find
																		// id to
																		// be
																		// updated
		if (selectUser == null) {
			return null;
		} else {
			// System.out.println("User id "+user.getId());
			selectUser.getName();// geting name from database
			selectUser.getUsername();// getting username from databas

			entityManager.getTransaction().commit();
			// End and flush transaction to database.
			return selectUser;
		}
	}

	public List<User> ListUser() {

		// Get EntityManger from factory.
		EntityManager entityManager = entityManagerFactory
				.createEntityManager();

		// Being Transaction
		entityManager.getTransaction().begin();
		List<User> user1 = entityManager.createQuery("from User", User.class)
				.getResultList();

		entityManager.getTransaction().commit();
		// End and flush transaction to database.
		return user1;
	}

	public UserService() {
	}

}
