package com.mkyong.common.controller;

public class ValidateUserInput {

	public User ValidateInt(User user){
		if(user.getName()==(String) (user.getName()))
		{
			return user;
		}
		return null;
	}
	
}
