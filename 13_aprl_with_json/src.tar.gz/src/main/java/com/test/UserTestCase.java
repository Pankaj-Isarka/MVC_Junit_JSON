package com.test;

import static org.junit.Assert.*;

import java.util.List;
import java.util.regex.Pattern;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mkyong.common.controller.User;
import com.mkyong.common.controller.UserService;
import com.mkyong.common.controller.ValidateUserInput;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:mvc-dispatcher-servlet.xml" })
public class UserTestCase {

	@Autowired
	UserService userService;
	ValidateUserInput validateUser;

	@Test
	public void testAddUser() {
		System.out.println("Testing Add User.");

		User user = new User();
		user.setName("TestName1");
		user.setUsername("TestUserName_1");

		User savedUser = userService.addUser(user);
		if (savedUser != null) {
			assertNotNull(savedUser);
			assertNotNull(savedUser.getId());
			assertEquals("TestName", savedUser.getName());

			System.out.println("User added: " + savedUser.toString());
		} else {
			System.out.println("Invalid Input");
			assertFalse("Invalid Input", true);
			//assertFalse(true);
		}
	}

	@Test
	public void testUpdateUser() {
		System.out.println("Testing Update User.");

		User user = new User();
		user.setId(51);
		user.setName("TestUpdate1");
		user.setUsername("TestUpdate2");

		User updateUser = userService.UpdateUser(user);
		if (updateUser == null) {
			System.out.println("Not Record Found");
			User finduser = userService.FindUser(user);

			assertNull(finduser);
		} else {

			assertNotNull(updateUser);
			assertEquals("TestUpdate1", updateUser.getName());

			System.out.println("User updated: " + updateUser.toString());
		}
	}

	@Test
	public void testdeleteUser() {
		System.out.println("Testing delete User.");

		User user = new User();
		user.setId(70);
		User deleteUser = userService.DeleteUser(user);
		if (deleteUser == null) {
			System.out.println("Not Record Found");
			User finduser = userService.FindUser(user);
			assertNull(finduser);
		} else {
			User finduser = userService.FindUser(deleteUser);
			assertNull(finduser);

		}
	}

	@Test
	public void testSelectUser() {
		System.out.println("Testing Select User.");

		User user = new User();
		user.setId(49);
		User findUser = userService.FindUser(user);
		if (findUser == null) {
			System.out.println("Not Record Found");
			assertNull(user.getName());
		} else {

			assertEquals(49, findUser.getId());
			assertEquals("TestName_1", findUser.getName());

		}
	}

	@Test
	public void testListUser() {
		System.out.println("Testing List of User.");

		List<User> user = userService.ListUser();

		System.out.println(user.size());

		assertEquals(33, user.size());
	}

}
